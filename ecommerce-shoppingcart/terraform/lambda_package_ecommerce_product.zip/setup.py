from setuptools import setup

setup(name='ecommerce_product',
      version='1.0.0',
      description='E-Commerce Product',
      author='Adrian Dolha',
      author_email='adriandolha@yahoo.com',
      url='https://github.com/adriandolha/ecommerce-demo.git',
      packages=['ecommerce_product']
      )
